<?php
    if (!empty($this->session->flashdata('pesan'))) {?>
    <div class="alert alert-success" role="alert"><?= $this->session->flashdata('pesan');?></div>
    <?php }
?>

<div class="row">
    <div class="col-md-12">
        <a href="<?php base_url()?>buku/tambah_buku" class="btn btn-success"><i class="fa fa-plus"></i>Tambah Buku</a>
    </div>
</div>

<br>

<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Table</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID Buku</th>
                    <th>ID Pengarang</th>
                    <th>ID Penerbit</th>
                    <th>Judul Buku</th>
                    <th>Tahun Terbit</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>
                  
                </tr>
            </thead>
            <tbody>
               
            
            </tbody>
        </table>
    </div>
</div>