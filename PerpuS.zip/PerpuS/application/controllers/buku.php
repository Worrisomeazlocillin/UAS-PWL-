<?php

class Buku extends CI_Controller{

    public function index()
    {
        $isi['content'] = 'buku/viewbuku';
        $isi['judul'] = 'Daftar Data Buku';
        $this->load->view('viewdashboard', $isi);
    }

    public function tambah_buku()
    {
        $isi['content'] = 'buku/form_buku';
        $isi['judul'] = 'Form Tambah Buku';
        $isi['pengarang'] = $this->db->get('pengarang')->result();
        $this->load->view('viewdashboard', $isi);
    }
}