<?php

class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
    }

    public function index() 
    {
        $this->m_akses->getAkses();
        $isi['content'] = 'viewhome';
        $isi['judul'] = 'Home';
        $this->load->view('viewdashboard',$isi);
    }
}